import config from '~/src/config.ts';

import * as discord from '~/src/discordV2.ts';
import { AvailableLocales } from '~/src/discord.ts';

import packs from '~/src/packs.ts';
import user from '~/src/user.ts';
import gacha from '~/src/gacha.ts';

import i18n from '~/src/i18n.ts';
import utils, { ImageSize } from '~/src/utils.ts';

import db from '~/db/index.ts';

import { NonFetalError, PoolError } from '~/src/errors.ts';

import type { Character } from '~/src/types.ts';

import type * as Schema from '~/db/schema.ts';

import type { WithId } from 'mongodb';

type CharacterWithId = WithId<Schema.Character>;

async function getFilteredCharacters({
  userId,
  guildId,
}: {
  userId: string;
  guildId: string;
}): Promise<WithId<CharacterWithId>[]> {
  const mongo = await db.newMongo().connect();

  const { user, party } = await db.getInventory(guildId, userId, mongo, true);

  const likesCharactersIds = user.likes
    ?.map(({ characterId }) => characterId)
    .filter(utils.nonNullable);

  const likesMediaIds = user.likes
    ?.map(({ mediaId }) => mediaId)
    .filter(utils.nonNullable);

  const characters = await db.getUserCharacters(userId, guildId, mongo, true);

  const partyIds = [
    party.member1?.characterId,
    party.member2?.characterId,
    party.member3?.characterId,
    party.member4?.characterId,
    party.member5?.characterId,
  ];

  await mongo.close();

  return characters.filter((char) => {
    if (
      partyIds.includes(char.characterId) ||
      likesCharactersIds.includes(char.characterId) ||
      likesMediaIds.includes(char.mediaId)
    ) {
      return false;
    }

    return true;
  });
}

function getSacrifices(
  characters: CharacterWithId[],
  mode: 'target' | 'min' | 'max',
  target?: number,
  locale?: AvailableLocales
): { sacrifices: CharacterWithId[]; target: number } {
  // I'm sure there is a faster way to do this with just math
  // but i am not smart enough to figure it out
  // the important thing is that all the tests pass

  const split: Record<number, CharacterWithId[]> = {
    1: [],
    2: [],
    3: [],
    4: [],
    5: [],
  };

  // separate each rating into its own array
  characters
    .sort((a, b) => a.rating - b.rating)
    .forEach((char) => {
      split[char.rating === 5 ? 4 : char.rating].push(char);
    });

  const possibilities: Record<number, CharacterWithId[][]> = {
    1: [],
    2: [],
    3: [],
    4: [],
    5: [],
  };

  [1, 2, 3, 4, 5].forEach((i) => {
    // break if target is possible
    if (target && possibilities[target].length) {
      return;
    }

    if (i > 1) {
      // since we need 5 characters from the previous rating
      // to make a new rating
      // divide the length of characters by 5 then floor it
      // to get how many new characters are possible to make
      const length = Math.floor(possibilities[i - 1].length / 5);

      possibilities[i].push(
        // split the previous possibilities into arrays of 5
        ...utils
          .chunks(possibilities[i - 1], 5)
          // only use the required amount of chunks
          .slice(0, length)
          // flatten them so all of them are Character[] instead of Character[][]
          .map((t) => t.flat())
      );
    }

    // add the current ratings to the possibilities list
    possibilities[i].push(...split[i].map((c) => [c]));
  });

  switch (mode) {
    case 'min':
      [5, 4, 3, 2].forEach((n) => {
        const index = possibilities[n].findIndex((t) => t.length >= 5);

        if (index > -1) {
          target = n;
        }
      });
      break;
    case 'max':
      [2, 3, 4, 5].forEach((n) => {
        const index = possibilities[n].findIndex((t) => t.length >= 5);

        if (index > -1) {
          target = n;
        }
      });
      break;
    default:
      break;
  }

  if (!target) {
    throw new NonFetalError(i18n.get('merge-not-possible', locale));
  }

  const index = possibilities[target].findIndex((t) => t.length >= 5);

  if (index === -1) {
    throw new NonFetalError(
      i18n.get(
        'merge-insufficient',
        locale,
        possibilities[target - 1].length,
        `${target}${discord.emotes.smolStar}`
      )
    );
  }

  return {
    target,
    sacrifices: possibilities[target][index],
  };
}

async function characterPreview(
  message: discord.Message,
  character: Character,
  existing: Partial<CharacterWithId>
): Promise<discord.Container> {
  const image = existing?.image
    ? { url: existing?.image }
    : character.images?.[0];

  const media = character.media?.edges?.[0]?.node;

  const name = `${existing.rating}${discord.emotes.smolStar}${utils.wrap(
    existing?.nickname ?? packs.aliasToArray(character.name)[0]
  )}`;

  const container = new discord.Container();
  const thumbnail = new discord.Thumbnail();
  const section = new discord.Section();

  const attachment = await thumbnail.setWithProxy({
    size: ImageSize.Thumbnail,
    url: image?.url,
  });

  if (media) {
    section.addText(
      new discord.TextDisplay(
        `${utils.wrap(packs.aliasToArray(media.title)[0])}\n**${name}**`
      )
    );
  } else {
    section.addText(new discord.TextDisplay(`**${name}**`));
  }

  message.addAttachment(attachment);
  section.setAccessory(thumbnail);

  return container.addComponent(section);
}

function synthesize({
  token,
  userId,
  guildId,
  mode,
  target,
}: {
  token: string;
  userId: string;
  guildId: string;
  mode: 'target' | 'min' | 'max';
  target?: number;
}) {
  const locale = user.cachedUsers[userId]?.locale;

  if (!config.synthesis) {
    throw new NonFetalError(i18n.get('maintenance-merge', locale));
  }

  // const message = new discord.Message();
  return synthesis
    .getFilteredCharacters({ userId, guildId })
    .then(async (characters) => {
      const message = new discord.Message();

      // eslint-disable-next-line prefer-const
      let { sacrifices, target: _target } = getSacrifices(
        characters,
        mode,
        target,
        locale
      );

      sacrifices = sacrifices.sort((a, b) => b.rating - a.rating);

      // highlight the top characters
      const highlights = sacrifices.slice(0, 5);

      const highlightedCharacters = await packs.characters({
        ids: highlights.map((char) => char.characterId),
        guildId,
      });

      message.addComponent(
        new discord.Container().addComponent(
          new discord.TextDisplay(
            i18n.get('merge-sacrifice', locale, sacrifices.length)
          )
        )
      );

      for (const existing of highlights) {
        const index = highlightedCharacters.findIndex(
          (char) => existing.characterId === `${char.packId}:${char.id}`
        );

        if (index > -1) {
          const character = await packs.aggregate<Character>({
            character: highlightedCharacters[index],
            guildId,
          });

          const media = character?.media?.edges?.[0]?.node;

          if (
            packs.isDisabled(existing.mediaId, guildId) ||
            (media && packs.isDisabled(`${media.packId}:${media.id}`, guildId))
          ) {
            highlightedCharacters.splice(index, 1);
            continue;
          }

          const container = await synthesis.characterPreview(
            message,
            character,
            existing
          );

          message.addComponent(container);
        }
      }

      if (sacrifices.length - highlightedCharacters.length) {
        message.addComponent(
          new discord.Container().addComponent(
            new discord.TextDisplay(
              `_+${sacrifices.length - highlightedCharacters.length} others..._`
            )
          )
        );
      }

      await discord.Message.dialog({
        userId,
        message,
        confirm: ['synthesis', userId, `${_target}`],
        locale,
      }).patch(token);
    })
    .catch(async (err) => {
      if (err instanceof NonFetalError) {
        return await new discord.Message()
          .addComponent(
            new discord.Container().addComponent(
              new discord.TextDisplay(err.message)
            )
          )
          .patch(token);
      }

      if (!config.sentry) {
        throw err;
      }

      const refId = utils.captureException(err);

      await discord.Message.internal(refId).patch(token);
    });
}

function confirmed({
  token,
  userId,
  guildId,
  target,
}: {
  token: string;
  userId: string;
  guildId: string;
  target: number;
}) {
  const locale = user.cachedUsers[userId]?.locale;

  return synthesis
    .getFilteredCharacters({ userId, guildId })
    .then(async (characters) => {
      const { sacrifices } = getSacrifices(
        characters,
        'target',
        target,
        locale
      );

      const pull = await gacha.rngPull({
        userId,
        guildId,
        guarantee: target,
        sacrifices: sacrifices.map(({ _id }) => _id),
      });

      return gacha.pullAnimation({
        token,
        guildId,
        userId,
        pull,
        components: false,
      });
    })
    .catch(async (err) => {
      if (err instanceof PoolError) {
        return await new discord.Message()
          .addComponent(
            new discord.Container().addComponent(
              new discord.TextDisplay(
                i18n.get(
                  'gacha-no-more-characters-left',
                  locale,
                  `${target}${discord.emotes.smolStar}`
                )
              )
            )
          )
          .patch(token);
      }

      if (err instanceof NonFetalError) {
        return await new discord.Message()
          .addComponent(
            new discord.Container().addComponent(
              new discord.TextDisplay(err.message)
            )
          )
          .patch(token);
      }

      if (!config.sentry) {
        throw err;
      }

      const refId = utils.captureException(err);

      await discord.Message.internal(refId).patch(token);
    });
}

const synthesis = {
  getFilteredCharacters,
  getSacrifices,
  characterPreview,
  synthesize,
  confirmed,
};

export default synthesis;
