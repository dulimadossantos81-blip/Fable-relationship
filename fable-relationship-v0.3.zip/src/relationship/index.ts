import * as discord from '~/src/discord.ts';
import packs from '~/src/packs.ts';
import { Mongo } from '~/db/index.ts';
import {
  addMemory,
  ensureRelationship,
  getMemories,
  getRelationship,
  giveGift,
  interact,
  listRelationships,
  setStatus,
} from '~/db/relationship/relationships.ts';
import { generateReply } from '~/src/relationship/ai.ts';
import type { Character } from '~/src/types.ts';
import type { RelationshipMood } from '~/db/relationship/schema.ts';


async function assertOwnedCharacter({
  mongo,
  userId,
  guildId,
  characterId,
}: {
  mongo: Mongo;
  userId: string;
  guildId: string;
  characterId: string;
}): Promise<boolean> {
  return Boolean(
    await mongo.characters().findOne({ userId, guildId, characterId }),
  );
}

function characterName(character: Character): string {
  return character.name.english ?? character.name.alternative?.[0] ?? character.id;
}

function statusLabel(status: string): string {
  return status.replaceAll('_', ' ');
}

function moodLabel(mood: RelationshipMood): string {
  return mood.replaceAll('_', ' ');
}

async function loadCharacter(characterId: string, guildId: string): Promise<Character> {
  const found = await packs.findById<Character>({
    key: 'characters',
    ids: [characterId],
    guildId,
  });
  const character = found[characterId];
  if (!character) throw new Error('Character not found');
  return await packs.aggregate<Character>({ character, guildId });
}

export async function onCharacterAcquired({ userId, guildId, characterId }: {
  userId: string;
  guildId: string;
  characterId: string;
}): Promise<void> {
  const mongo = await new Mongo().connect();
  try {
    await ensureRelationship({ mongo, userId, guildId, characterId });
  } finally {
    await mongo.close();
  }
}

function profileComponents(characterId: string): discord.Component[] {
  return [
    new discord.Component().setId('relationship', characterId, 'talk').setLabel('💬 Conversar'),
    new discord.Component().setId('relationship', characterId, 'tea').setLabel('🍵 Tomar chá'),
    new discord.Component().setId('relationship', characterId, 'date').setLabel('🌸 Passear'),
    new discord.Component().setId('relationship', characterId, 'gift').setLabel('🎁 Presente'),
    new discord.Component().setId('relationship', characterId, 'memories').setLabel('🧠 Memórias'),
  ];
}

async function profile({ userId, guildId, characterId }: {
  userId: string;
  guildId: string;
  characterId: string;
}): Promise<discord.Message> {
  const mongo = await new Mongo().connect();
  try {
    const relationship = await getRelationship(mongo, userId, guildId, characterId);
    if (!relationship) {
      return new discord.Message()
        .setContent('❤️ Você ainda não criou um vínculo com essa personagem.')
        .setFlags(discord.MessageFlags.Ephemeral);
    }

    const character = await loadCharacter(characterId, guildId);
    return new discord.Message()
      .addEmbed(
        new discord.Embed()
          .setTitle(`❤️ ${characterName(character)}`)
          .setDescription([
            `**Status:** ${statusLabel(relationship.status)}`,
            `**Humor:** ${moodLabel(relationship.mood)}`,
            `**Afeto:** ${relationship.affection}/100`,
            `**Confiança:** ${relationship.trust}/100`,
            `**Intimidade:** ${relationship.intimacy}/100`,
            `**Compatibilidade:** ${relationship.compatibility}/100`,
            '',
            `**Interações:** ${relationship.interactionCount}`,
            `**Conversas:** ${relationship.conversationsCount}`,
            `**Passeios:** ${relationship.datesCount}`,
            `**Presentes:** ${relationship.giftsGiven}`,
          ].join('\n')),
      )
      .addComponents(profileComponents(characterId));
  } finally {
    await mongo.close();
  }
}

function modal({ characterId, action }: { characterId: string; action: string }): discord.Message {
  const label = action === 'gift' ? 'Qual presente?' : action === 'date' ? 'O que vocês vão fazer?' : 'Diga alguma coisa';
  return new discord.Message()
    .setTitle(action === 'gift' ? '🎁 Dar um presente' : action === 'date' ? '🌸 Planejar passeio' : '💬 Conversar')
    .setId('relationship_modal', characterId, action)
    .addComponents([
      new discord.Component(discord.ComponentType.TextInput)
        .setId('message')
        .setLabel(label)
        .setMinLength(1)
        .setMaxLength(1000)
        .setRequired(true)
        .setPlaceholder(action === 'gift' ? 'Ex.: uma caixa de chocolates' : 'Escreva aqui...'),
    ]);
}

async function runInteraction({
  userId,
  guildId,
  characterId,
  action,
  userMessage,
  token,
}: {
  userId: string;
  guildId: string;
  characterId: string;
  action: string;
  userMessage?: string;
  token: string;
}): Promise<void> {
  const mongo = await new Mongo().connect();
  try {
    const character = await loadCharacter(characterId, guildId);
    if (!(await assertOwnedCharacter({ mongo, userId, guildId, characterId }))) {
      await new discord.Message()
        .setContent('❤️ Você precisa possuir essa personagem no Fable para interagir com ela.')
        .setFlags(discord.MessageFlags.Ephemeral)
        .patch(token);
      return;
    }
    const existing = await getRelationship(mongo, userId, guildId, characterId);
    if (!existing) {
      await new discord.Message()
        .setContent('❤️ Esse vínculo ainda não foi inicializado. Faça um novo pull dessa personagem.')
        .setFlags(discord.MessageFlags.Ephemeral)
        .patch(token);
      return;
    }
    let relationship = existing;
    if (action === 'date' && !['close_friend', 'romantic_interest', 'dating', 'engaged', 'married'].includes(relationship.status)) {
      await new discord.Message()
        .setContent('🌸 Esse tipo de passeio é especial. Fortaleça o vínculo até pelo menos **amigos próximos** primeiro.')
        .setFlags(discord.MessageFlags.Ephemeral)
        .patch(token);
      return;
    }
    let prompt = userMessage?.trim() ?? '';
    let scene = 'Uma conversa cotidiana.';
    let mood: RelationshipMood = 'calm';
    let affectionDelta = 2;
    let trustDelta = 1;
    let intimacyDelta = 0;
    let compatibilityDelta = 0;
    let date = false;

    switch (action) {
      case 'tea':
        prompt ||= 'Você convidou a personagem para tomar chá. Responda com uma cena curta, acolhedora e coerente com a personalidade dela.';
        scene = 'Vocês estão tomando chá juntos em um momento tranquilo.';
        mood = 'calm';
        affectionDelta = 3;
        trustDelta = 2;
        break;
      case 'date':
        scene = 'Vocês estão em um passeio juntos. O usuário descreveu o plano do passeio.';
        prompt ||= 'Vocês saíram juntos para um passeio. Reaja à situação de forma natural.';
        mood = 'happy';
        affectionDelta = 5;
        trustDelta = 2;
        compatibilityDelta = 1;
        date = true;
        break;
      case 'gift':
        relationship = await giveGift({
          mongo,
          userId,
          guildId,
          characterId,
          gift: prompt || 'um presente',
        });
        scene = `O usuário acabou de dar este presente: ${prompt || 'um presente'}.`;
        prompt = `Você recebeu este presente: ${prompt || 'um presente'}. Reaja como a personagem, levando em conta sua personalidade e o relacionamento atual.`;
        mood = 'happy';
        break;
      default:
        prompt ||= 'O usuário iniciou uma conversa. Responda como a personagem e mantenha a personalidade consistente.';
        mood = relationship.affection >= 70 ? 'playful' : 'curious';
        break;
    }

    if (action !== 'gift') {
      relationship = await interact({
        mongo,
        userId,
        guildId,
        characterId,
        affectionDelta,
        trustDelta,
        intimacyDelta,
        compatibilityDelta,
        mood,
        conversation: action === 'talk',
        date,
      });
    }

    const memories = await getMemories({ mongo, userId, guildId, characterId, limit: 12 });
    const reply = await generateReply({ character, relationship, memories, userMessage: prompt, scene });

    const importance = action === 'date' || action === 'gift' ? 3 : 1;
    await addMemory({
      mongo,
      relationship,
      text: `${action}: ${prompt.slice(0, 700)} → ${reply.slice(0, 1200)}`,
      kind: importance >= 3 ? 'long_term' : 'short_term',
      importance,
    });

    await new discord.Message()
      .addEmbed(
        new discord.Embed()
          .setTitle(`${action === 'tea' ? '🍵' : action === 'date' ? '🌸' : action === 'gift' ? '🎁' : '💬'} ${characterName(character)}`)
          .setDescription(reply)
          .setFooter({
            text: `❤️ ${relationship.affection}/100 • 🤝 ${relationship.trust}/100 • ${statusLabel(relationship.status)}`,
          }),
      )
      .addComponents([
        new discord.Component().setId('relationship', characterId, 'talk').setLabel('💬 Continuar'),
        new discord.Component().setId('relationship', characterId, 'tea').setLabel('🍵 Chá'),
        new discord.Component().setId('relationship', characterId, 'profile').setLabel('❤️ Perfil'),
      ])
      .patch(token);
  } finally {
    await mongo.close();
  }
}

async function memories({ userId, guildId, characterId }: {
  userId: string;
  guildId: string;
  characterId: string;
}): Promise<discord.Message> {
  const mongo = await new Mongo().connect();
  try {
    const character = await loadCharacter(characterId, guildId);
    const items = await getMemories({ mongo, userId, guildId, characterId, limit: 15 });
    return new discord.Message().addEmbed(
      new discord.Embed()
        .setTitle(`🧠 Memórias — ${characterName(character)}`)
        .setDescription(items.length ? items.map((m) => `• **${m.kind}** — ${m.text}`).join('\n\n') : 'Ainda não existem memórias.'),
    ).setFlags(discord.MessageFlags.Ephemeral);
  } finally {
    await mongo.close();
  }
}

async function list({ userId, guildId }: { userId: string; guildId: string }): Promise<discord.Message> {
  const mongo = await new Mongo().connect();
  try {
    const relationships = await listRelationships({ mongo, userId, guildId });
    if (!relationships.length) return new discord.Message().setContent('❤️ Você ainda não tem relacionamentos.');

    const names = await Promise.all(relationships.map(async (r) => {
      try {
        const character = await loadCharacter(r.characterId, guildId);
        return `• **${characterName(character)}** — ${statusLabel(r.status)} • ❤️ ${r.affection}`;
      } catch {
        return `• **${r.characterId}** — ${statusLabel(r.status)} • ❤️ ${r.affection}`;
      }
    }));

    return new discord.Message().addEmbed(
      new discord.Embed().setTitle('❤️ Seus relacionamentos').setDescription(names.join('\n')),
    );
  } finally {
    await mongo.close();
  }
}

export async function command({
  subcommand,
  userId,
  guildId,
  characterId,
}: {
  subcommand?: string;
  userId: string;
  guildId: string;
  characterId?: string;
}): Promise<discord.Message> {
  if (subcommand === 'list') return list({ userId, guildId });
  if (!characterId) {
    return new discord.Message().setContent('Escolha uma personagem.').setFlags(discord.MessageFlags.Ephemeral);
  }
  if (subcommand === 'memories') return memories({ userId, guildId, characterId });
  if (['interact', 'tea', 'date', 'gift'].includes(subcommand ?? '')) {
    return modal({ characterId, action: subcommand === 'interact' ? 'talk' : subcommand! });
  }
  return profile({ userId, guildId, characterId });
}

export async function interactNow({ userId, guildId, characterId, action, userMessage, token }: {
  userId: string;
  guildId: string;
  characterId: string;
  action: string;
  userMessage?: string;
  token: string;
}): Promise<void> {
  await runInteraction({ userId, guildId, characterId, action, userMessage, token });
}

export async function component({ userId, guildId, characterId, action }: {
  userId: string;
  guildId: string;
  characterId: string;
  action: string;
}): Promise<discord.Message> {
  if (['talk', 'date', 'gift'].includes(action)) return modal({ characterId, action });
  if (action === 'memories') return memories({ userId, guildId, characterId });
  return profile({ userId, guildId, characterId });
}
