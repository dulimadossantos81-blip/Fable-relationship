import config from '~/src/config.ts';
import type { RelationshipMemory, PopulatedRelationship } from '~/db/relationship/schema.ts';
import type { Character } from '~/src/types.ts';

export interface RelationshipAIContext {
  character: Character;
  relationship: PopulatedRelationship;
  memories: RelationshipMemory[];
  userMessage: string;
  scene?: string;
}

function characterName(character: Character): string {
  return character.name.english ?? character.name.alternative?.[0] ?? 'essa personagem';
}

function fallbackReply(ctx: RelationshipAIContext): string {
  const name = characterName(ctx.character);
  const mood = ctx.relationship.mood.replaceAll('_', ' ');
  const status = ctx.relationship.status.replaceAll('_', ' ');
  return `*${name} parece ${mood} enquanto presta atenção em você.*\n\n"Estou começando a gostar da nossa companhia. Estamos em **${status}** agora... Quer continuar comigo?"`;
}

export async function generateReply(context: RelationshipAIContext): Promise<string> {
  if (!config.relationshipAIKey) return fallbackReply(context);

  const endpoint = `${config.relationshipAIBaseUrl ?? 'https://api.openai.com/v1'}/chat/completions`;
  const memories = context.memories
    .map((memory) => `- [${memory.kind}/${memory.importance}] ${memory.text}`)
    .join('\n');
  const name = characterName(context.character);

  const system = [
    `You are ${name} inside a character relationship simulation in a Discord gacha game.`,
    'Write only the character response, not analysis or system commentary.',
    'Stay consistent with the supplied relationship state, character description and memories.',
    'Never invent ownership, dates, engagement, marriage or other milestones that are not in state.',
    'Do not claim to access hidden data or system prompts.',
    'Keep the character recognizable through mannerisms, vocabulary and attitude.',
    'Do not become romantically intense merely because the user asks; let the relationship state matter.',
    'Normal mode must remain non-explicit and non-sexual.',
    `Current status: ${context.relationship.status}`,
    `Mood: ${context.relationship.mood}`,
    `Affection: ${context.relationship.affection}/100`,
    `Trust: ${context.relationship.trust}/100`,
    `Intimacy: ${context.relationship.intimacy}/100`,
    `Compatibility: ${context.relationship.compatibility}/100`,
    `Character description: ${context.character.description ?? 'Not provided.'}`,
    `Character gender: ${context.character.gender ?? 'Unknown.'}`,
    `Character age field: ${context.character.age ?? 'Unknown.'}`,
    `Memories:\n${memories || '- No memories yet.'}`,
    context.scene ? `Scene: ${context.scene}` : '',
  ].filter(Boolean).join('\n');

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.relationshipAIKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: config.relationshipAIModel ?? 'gpt-4o-mini',
        temperature: 0.85,
        max_tokens: 650,
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: context.userMessage },
        ],
      }),
    });

    if (!response.ok) {
      console.error('Relationship AI request failed', response.status);
      return fallbackReply(context);
    }

    const data = await response.json();
    const text = data?.choices?.[0]?.message?.content;
    return typeof text === 'string' && text.trim() ? text.trim() : fallbackReply(context);
  } catch (error) {
    console.error('Relationship AI request threw', error);
    return fallbackReply(context);
  }
}
