# Relationship Extension — V0.1

This fork adds a modular relationship subsystem to Fable.

## Included

- Relationship persistence per `userId + guildId + characterId`.
- Affection, trust, intimacy and relationship status.
- First-meeting milestone.
- Short-term relationship memories.
- `/relationship` command with `profile`, `interact` and `list` actions.
- Character autocomplete using Fable's existing character search.
- `❤️ Interagir` button on successful character pulls.
- Conversation and tea interactions.
- Optional AI generation through an OpenAI-compatible Chat Completions endpoint.
- Deterministic fallback dialogue when no AI key is configured.
- AI receives relationship state and memories, but does not own authoritative state.

## Environment

Add to `.env`:

```env
RELATIONSHIP_AI_KEY=
RELATIONSHIP_AI_BASE_URL=https://api.openai.com/v1
RELATIONSHIP_AI_MODEL=gpt-4o-mini
```

The AI integration is optional in V0.1.

## Database

Run the existing Fable index script after deploying the code:

```bash
npx tsx vite-node.ts db/_ensureIndexes.ts
```

The extension creates:

- `relationships`
- `relationship_memories`

## First commands

```text
/relationship action:list
/relationship action:profile character:<character>
/relationship action:interact character:<character> message:<text>
```

The character must be available in the guild's installed Fable packs.

## Design rule

Fable remains authoritative for gacha and ownership. The relationship module is authoritative for relationship state and memories. The AI is a renderer/actor, not the source of truth.
