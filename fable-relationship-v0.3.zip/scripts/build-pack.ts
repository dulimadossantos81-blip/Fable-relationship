import { readdir, readFile, mkdir, writeFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';

const ROOT = join(process.cwd(), 'pack-data', 'relationship-anime-01');
const CHAR_DIR = join(ROOT, 'characters');
const MEDIA_DIR = join(ROOT, 'media');
const OUT_DIR = join(ROOT, 'generated');

const ID_RE = /^[-_a-z0-9]+$/;
const PACK_ID_RE = /^[-_a-z0-9]+$/;
const FABLE_MEDIA_TYPES = new Set(['ANIME', 'MANGA', 'OTHER']);
const FABLE_MEDIA_FORMATS = new Set([
  'TV', 'TV_SHORT', 'MOVIE', 'SPECIAL', 'OVA', 'ONA', 'MUSIC',
  'MANGA', 'VIDEO_GAME', 'NOVEL', 'ONE_SHOT',
]);
const ROLES = new Set(['MAIN', 'SUPPORTING', 'BACKGROUND']);

async function readJson<T>(path: string): Promise<T> {
  return JSON.parse(await readFile(path, 'utf8')) as T;
}

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

export async function main() {
  const sourceManifest = await readJson<any>(join(ROOT, 'manifest.json'));
  assert(PACK_ID_RE.test(sourceManifest.id), `Invalid pack id: ${sourceManifest.id}`);

  const charFiles = (await readdir(CHAR_DIR)).filter((f) => f.endsWith('.json')).sort();
  const mediaFiles = (await readdir(MEDIA_DIR)).filter((f) => f.endsWith('.json')).sort();

  const media = await Promise.all(mediaFiles.map((f) => readJson<any>(join(MEDIA_DIR, f))));
  const chars = await Promise.all(charFiles.map((f) => readJson<any>(join(CHAR_DIR, f))));

  const mediaIds = new Set<string>();
  for (const item of media) {
    assert(ID_RE.test(item.id), `Invalid media id: ${item.id}`);
    assert(!mediaIds.has(item.id), `Duplicate media id: ${item.id}`);
    mediaIds.add(item.id);
    assert(FABLE_MEDIA_TYPES.has(item.type), `Invalid media type for ${item.id}: ${item.type}`);
    if (item.format !== undefined) {
      assert(FABLE_MEDIA_FORMATS.has(item.format), `Invalid media format for ${item.id}: ${item.format}`);
    }
  }

  const charIds = new Set<string>();
  const normalizedChars: any[] = [];
  const roleByMedia = new Map<string, any[]>();

  for (const item of chars) {
    assert(ID_RE.test(item.id), `Invalid character id: ${item.id}`);
    assert(!charIds.has(item.id), `Duplicate character id: ${item.id}`);
    charIds.add(item.id);
    assert(Number.isInteger(item.rating) && item.rating >= 1 && item.rating <= 5, `Invalid rating for ${item.id}`);

    if (item.adultVersion?.enabled) {
      const adultAge = Number(item.adultVersion.age);
      assert(Number.isFinite(adultAge) && adultAge >= 18 && adultAge <= 30, `Adult age for ${item.id} must be between 18 and 30`);
    }

    const mediaId = item.mediaId;
    assert(typeof mediaId === 'string' && mediaIds.has(mediaId), `Missing media ${mediaId} for character ${item.id}`);
    const role = item.role ?? 'MAIN';
    assert(ROLES.has(role), `Invalid role for ${item.id}: ${role}`);

    const fableChar = {
      id: item.id,
      packId: sourceManifest.id,
      name: item.name,
      ...(item.description ? { description: item.description } : {}),
      rating: item.rating,
      ...(item.gender ? { gender: item.gender } : {}),
      ...(item.age ? { age: item.age } : {}),
      ...(item.images?.length ? { images: item.images } : { images: [] }),
      ...(item.externalLinks?.length ? { externalLinks: item.externalLinks } : {}),
      media: [{ role, mediaId: `${sourceManifest.id}:${mediaId}` }],
    };
    normalizedChars.push(fableChar);

    const list = roleByMedia.get(mediaId) ?? [];
    list.push({ role, characterId: `${sourceManifest.id}:${item.id}` });
    roleByMedia.set(mediaId, list);
  }

  assert(charIds.has('anya-forger'), 'Anya must exist in the pack');
  const anya = chars.find((c) => c.id === 'anya-forger');
  assert(anya?.adultVersion?.enabled === false, 'Anya must never have an adult version enabled');
  const danteWill = chars.find((c) => c.id === 'dante-will');
  assert(danteWill?.adultVersion?.enabled === false, 'DanteWill must not have an adult version enabled');

  const normalizedMedia = media.map((item) => ({
    id: item.id,
    packId: sourceManifest.id,
    title: item.title,
    type: item.type,
    ...(item.format ? { format: item.format } : {}),
    ...(item.description ? { description: item.description } : {}),
    ...(item.images?.length ? { images: item.images } : { images: [] }),
    ...(item.externalLinks?.length ? { externalLinks: item.externalLinks } : {}),
    characters: roleByMedia.get(item.id) ?? [],
  }));

  const generatedManifest = {
    id: sourceManifest.id,
    ...(sourceManifest.title ? { title: sourceManifest.title } : {}),
    ...(sourceManifest.description ? { description: sourceManifest.description } : {}),
    ...(sourceManifest.author ? { author: sourceManifest.author } : {}),
    ...(sourceManifest.nsfw !== undefined ? { nsfw: sourceManifest.nsfw } : {}),
    ...(sourceManifest.private !== undefined ? { private: sourceManifest.private } : {}),
    media: normalizedMedia,
    characters: normalizedChars,
  };

  await mkdir(OUT_DIR, { recursive: true });
  await writeFile(join(OUT_DIR, 'merged-manifest.json'), `${JSON.stringify(generatedManifest, null, 2)}\n`);
  await writeFile(join(OUT_DIR, 'characters.json'), `${JSON.stringify(normalizedChars, null, 2)}\n`);
  await writeFile(join(OUT_DIR, 'media.json'), `${JSON.stringify(normalizedMedia, null, 2)}\n`);

  console.log(`OK: ${normalizedChars.length} characters, ${normalizedMedia.length} media.`);
  console.log(`Generated: ${join(OUT_DIR, 'merged-manifest.json')}`);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}
