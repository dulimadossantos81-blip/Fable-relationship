import json, os

root='/mnt/data/v03packbuild/pack-data/relationship-anime-01'
chars=root+'/characters'
media=root+'/media'
os.makedirs(chars, exist_ok=True); os.makedirs(media, exist_ok=True)

works={
'one-piece':('One Piece','ANIME','TV'),
'chainsaw-man':('Chainsaw Man','ANIME','TV'),
'spy-family':('Spy x Family','ANIME','TV'),
'naruto':('Naruto','ANIME','TV'),
'rezero':('Re:Zero − Starting Life in Another World','ANIME','TV'),
'undertale':('Undertale','VIDEO_GAME','VIDEO_GAME'),
'dragon-ball':('Dragon Ball','ANIME','TV'),
'bleach':('Bleach','ANIME','TV'),
'uma-musume':('Uma Musume: Pretty Derby','ANIME','TV'),
'dmc':('Devil May Cry','OTHER','VIDEO_GAME'),
'vocaloid':('Hatsune Miku / Vocaloid','OTHER','MUSIC'),
'one-punch-man':('One Punch Man','ANIME','TV'),
'dante-will':('DanteWill','OTHER','OTHER'),
}

entries=[
('nami','Nami','One Piece','one-piece','Female','20','MAIN','2',True,'Navegadora dos Piratas do Chapéu de Palha, conhecida por sua inteligência, determinação e amor por tesouros.'),
('nico-robin','Nico Robin','One Piece','one-piece','Female','30','MAIN','2',True,'Arqueóloga dos Chapéus de Palha, reservada, culta e perspicaz, com profundo interesse pela história.'),
('makima','Makima','Chainsaw Man','chainsaw-man','Female','', 'MAIN','3',True,'Figura enigmática e calculista ligada à Divisão de Segurança Pública, conhecida por sua postura serena e autoridade.'),
('yor-forger','Yor Forger','Spy x Family','spy-family','Female','27','MAIN','2',True,'Funcionária de aparência gentil que leva uma vida dupla como assassina habilidosa; dedicada à família que construiu.'),
('hinata-hyuga','Hinata Hyuga','Naruto','naruto','Female','19','MAIN','2',True,'Kunoichi de personalidade gentil e determinada, que desenvolve grande confiança ao longo de sua trajetória.'),
('sakura-haruno','Sakura Haruno','Naruto','naruto','Female','20','MAIN','2',True,'Kunoichi e médica ninja talentosa, disciplinada e com grande força física.'),
('emilia','Emilia','Re:Zero','rezero','Female','', 'MAIN','3',True,'Meia-elfa de cabelos prateados e personalidade compassiva, uma das principais figuras de Re:Zero.'),
('rem','Rem','Re:Zero','rezero','Female','18','MAIN','2',True,'Maid oni habilidosa, dedicada e protetora, famosa por sua lealdade e coragem.'),
('shaula','Shaula','Re:Zero','rezero','Female','','SUPPORTING','4',False,'Guardiã da Torre de Pleiades, excêntrica, extremamente poderosa e marcada por uma personalidade intensa.'),
('ram','Ram','Re:Zero','rezero','Female','18','SUPPORTING','2',True,'Maid oni de personalidade direta, confiante e sarcástica, com grande habilidade mágica.'),
('priscilla-barielle','Priscilla Barielle','Re:Zero','rezero','Female','19','MAIN','3',True,'Nobre extremamente confiante e orgulhosa, conhecida por sua presença dominante e personalidade extravagante.'),
('elsa-granhiert','Elsa Granhiert','Re:Zero','rezero','Female','', 'SUPPORTING','5',True,'Assassina conhecida por seu estilo de luta veloz e comportamento inquietante.'),
('frisk','Frisk','Undertale','undertale','', '', 'MAIN','2',False,'Protagonista silencioso de Undertale, cuja jornada pelo subterrâneo é moldada pelas escolhas do jogador.'),
('toriel','Toriel','Undertale','undertale','Female','','MAIN','2',False,'Monstro maternal e gentil que protege humanos e valoriza educação, segurança e cuidado.'),
('alphys','Alphys','Undertale','undertale','Female','','MAIN','2',False,'Cientista real tímida e brilhante, apaixonada por tecnologia, ficção e pesquisa.'),
('undyne','Undyne','Undertale','undertale','Female','','MAIN','3',False,'Capitã da Guarda Real, determinada, energética e extremamente dedicada ao treinamento e à justiça.'),
('monkey-d-luffy','Monkey D. Luffy','One Piece','one-piece','Male','19','MAIN','2',True,'Capitão dos Chapéus de Palha, otimista, impulsivo e determinado a alcançar seu sonho de liberdade.'),
('sans','Sans','Undertale','undertale','Male','','MAIN','3',False,'Esqueleto descontraído conhecido por suas piadas, preguiça aparente e surpreendente habilidade de combate.'),
('roronoa-zoro','Roronoa Zoro','One Piece','one-piece','Male','21','MAIN','2',True,'Espadachim dos Chapéus de Palha, extremamente disciplinado, determinado e leal aos seus companheiros.'),
('denji','Denji','Chainsaw Man','chainsaw-man','Male','16','MAIN','2',True,'Jovem caçador de demônios cuja vida muda drasticamente após se tornar o Homem-Motosserra.'),
('son-goku','Son Goku','Dragon Ball','dragon-ball','Male','','MAIN','1',True,'Guerreiro Saiyajin de espírito alegre, competitivo e sempre disposto a enfrentar novos desafios.'),
('bulma','Bulma','Dragon Ball','dragon-ball','Female','25','MAIN','2',True,'Inventora brilhante e aventureira, conhecida por sua inteligência, confiança e tecnologia.'),
('uzumaki-naruto','Naruto Uzumaki','Naruto','naruto','Male','19','MAIN','2',True,'Ninja determinado e expansivo que supera obstáculos com perseverança, amizade e criatividade.'),
('kurosaki-ichigo','Ichigo Kurosaki','Bleach','bleach','Male','17','MAIN','2',True,'Estudante que se torna substituto de Shinigami e assume a responsabilidade de proteger quem ama.'),
('orihime-inoue','Orihime Inoue','Bleach','bleach','Female','17','MAIN','2',True,'Estudante gentil e imaginativa, com poderes de rejeição e forte vínculo com seus amigos.'),
('yoruichi-shihouin','Yoruichi Shihōin','Bleach','bleach','Female','','MAIN','3',True,'Shinigami veterana extremamente veloz, confiante e experiente, com grande domínio de combate.'),
('matikanetannhauser','Matikanetannhauser','Uma Musume','uma-musume','Female','','MAIN','2',False,'Uma Musume alegre e azarada, conhecida pelo espírito positivo, energia e humor peculiar.'),
('dante-will','DanteWill','DanteWill','dante-will','', '', 'MAIN','3',False,'VTuber brasileiro conhecido como DanteWill; entrada tratada como personagem de mídia independente, sem modo adulto.'),
('dante-dmc','Dante','Devil May Cry','dmc','Male','','MAIN','3',True,'Caçador de demônios irreverente e confiante, famoso pelo humor, estilo de combate e atitude desafiadora.'),
('vergil-dmc','Vergil','Devil May Cry','dmc','Male','','MAIN','4',True,'Guerreiro extremamente disciplinado e focado em poder, precisão e domínio da espada.'),
('vegeta','Vegeta','Dragon Ball','dragon-ball','Male','','MAIN','2',True,'Príncipe Saiyajin orgulhoso e competitivo, cuja trajetória é marcada por ambição, rivalidade e crescimento.'),
('hatsune-miku','Hatsune Miku','Vocaloid','vocaloid','Female','', 'MAIN','2',True,'Ícone virtual e cantora digital associada ao Vocaloid, reconhecida por sua estética futurista e presença musical.'),
('kasane-teto','Kasane Teto','Vocaloid / UTAU','vocaloid','Female','','SUPPORTING','2',True,'Personagem virtual originalmente criada para UTAU, conhecida por seu design distinto e enorme presença na cultura de internet.'),
('saitama','Saitama','One Punch Man','one-punch-man','Male','25','MAIN','2',True,'Herói aparentemente comum que derrotou inúmeros inimigos com um único golpe, mantendo um jeito simples e apático.'),
('tatsumaki','Tatsumaki','One Punch Man','one-punch-man','Female','28','MAIN','3',True,'Heroína Classe S com poderes psíquicos extraordinários, personalidade confiante e temperamento explosivo.'),
('anya-forger','Anya Forger','Spy x Family','spy-family','Female','','MAIN','1',False,'Criança telepata adotada por Loid e Yor, curiosa, expressiva e peça central da família Forger.'),
]

for mid,(title,t,fmt) in works.items():
    # Correct non-enum media format values below; serializer uses strings accepted by Fable validators.
    if t=='VIDEO_GAME':
        mt='OTHER'
    else:
        mt=t
    if mid=='undertale':
        mf='VIDEO_GAME'
    elif mid=='dmc':
        mf='VIDEO_GAME'
    elif mid=='vocaloid':
        mf='MUSIC'
    elif mid=='dante-will':
        mf='OTHER'
    else:
        mf=fmt
    if mid=='dante-will':
        mf=None
    data={
      'id':mid,
      'title': {'english':title},
      'type': mt,
      **({'format': mf} if mf else {}),
      'description': f'Pack media entry for {title}.',
      'images': [],
      'characters': []
    }
    open(f'{media}/{mid}.json','w',encoding='utf-8').write(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

adult_ages = {
  'nami':20,'nico-robin':30,'makima':25,'yor-forger':27,'hinata-hyuga':19,'sakura-haruno':20,
  'emilia':19,'rem':18,'ram':18,'priscilla-barielle':19,'elsa-granhiert':20,'monkey-d-luffy':19,
  'roronoa-zoro':21,'denji':18,'son-goku':30,'bulma':25,'uzumaki-naruto':19,'kurosaki-ichigo':18,
  'orihime-inoue':18,'yoruichi-shihouin':25,'dante-dmc':30,'vergil-dmc':30,'vegeta':29,
  'hatsune-miku':20,'kasane-teto':20,'saitama':25,'tatsumaki':28
}

for (cid,name,work,mid,gender,age,role,rating,adult,desc) in entries:
    char={
      'id':cid,
      'name': {'english':name},
      'description':desc,
      'rating':int(rating),
      'gender':gender,
      'images':[],
      'mediaId':mid,
      'role':role,
      'adultVersion': {
        'enabled': bool(adult),
        'age': adult_ages.get(cid) if adult else None
      }
    }
    if name=='Matikanetannhauser':
        char['name']['alternative']=['Mambo']
    if age:
        char['age']=age
    open(f'{chars}/{cid}.json','w',encoding='utf-8').write(json.dumps(char,ensure_ascii=False,indent=2)+'\n')

manifest={
  '$schema':'https://packs.fable.ing/json/schema.json',
  'id':'relationship-anime-01',
  'title':'Relationship Anime Pack 01',
  'description':'Primeiro pack de personagens do Fable Relationship V0.3. Os campos adultVersion são metadados locais e não são enviados ao Fable.',
  'author':'Fable Relationship V0.3',
  'nsfw':False,
  'private':False,
  'image':'',
  'url':'',
  'media':{'new':[]},
  'characters':{'new':[]}
}
open(root+'/manifest.json','w',encoding='utf-8').write(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
open(root+'/README.md','w',encoding='utf-8').write('''# relationship-anime-01\n\nPrimeiro pack de dados do Fable Relationship V0.3.\n\n## Organização\n- `manifest.json`: identificação do pack.\n- `media/*.json`: uma obra/media por arquivo.\n- `characters/*.json`: uma personagem por arquivo.\n\nOs campos `adultVersion.enabled` e `adultVersion.age` são metadados locais do projeto. O carregador converte somente os campos compatíveis com o Fable e não envia esses metadados para a coleção de personagens.\n\nAs listas `images` estão vazias de propósito neste primeiro pacote; imagens devem ser adicionadas com URLs/licenças adequadas depois.\n''')

print('generated',len(entries),'characters and',len(works),'media')
