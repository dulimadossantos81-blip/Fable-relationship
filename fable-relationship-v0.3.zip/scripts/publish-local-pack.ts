import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import db from '~/db/index.ts';

const PACK_ID = 'relationship-anime-01';
const GENERATED = join(process.cwd(), 'pack-data', PACK_ID, 'generated');

export async function main() {
  const discordUserId = process.argv[2];
  if (!discordUserId || !/^\d+$/.test(discordUserId)) {
    throw new Error('Usage: npx tsx vite-node.ts scripts/publish-local-pack.ts <DISCORD_USER_ID>');
  }

  const merged = JSON.parse(await readFile(join(GENERATED, 'merged-manifest.json'), 'utf8'));
  const { characters, media, ...manifest } = merged;

  await db.publishPack(discordUserId, manifest, characters, media);
  console.log(`Published ${PACK_ID} to MongoDB.`);
}

if (import.meta.url.endsWith('/publish-local-pack.ts')) {
  main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}
