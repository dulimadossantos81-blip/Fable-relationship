# relationship-anime-01

Primeiro pack de dados do Fable Relationship V0.3.

## Organização
- `manifest.json`: identificação do pack.
- `media/*.json`: uma obra/media por arquivo.
- `characters/*.json`: uma personagem por arquivo.

Os campos `adultVersion.enabled` e `adultVersion.age` são metadados locais do projeto. O carregador converte somente os campos compatíveis com o Fable e não envia esses metadados para a coleção de personagens.

As listas `images` estão vazias de propósito neste primeiro pacote; imagens devem ser adicionadas com URLs/licenças adequadas depois.
