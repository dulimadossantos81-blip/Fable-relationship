import type { ObjectId, WithId } from 'mongodb';

export type RelationshipStatus =
  | 'met'
  | 'acquaintance'
  | 'friend'
  | 'close_friend'
  | 'romantic_interest'
  | 'dating'
  | 'engaged'
  | 'married';

export type RelationshipMood =
  | 'happy'
  | 'calm'
  | 'shy'
  | 'playful'
  | 'curious'
  | 'upset'
  | 'tired';

export interface RelationshipProfile {
  personality?: string;
  likes?: string[];
  dislikes?: string[];
  speechStyle?: string;
  notes?: string;
}

export interface Milestone {
  type: string;
  createdAt: Date;
  note?: string;
}

export interface Relationship {
  userId: string;
  guildId: string;
  characterId: string;

  status: RelationshipStatus;
  mood: RelationshipMood;
  affection: number;
  trust: number;
  intimacy: number;
  compatibility: number;

  firstMet: Date;
  lastInteraction: Date;
  interactionCount: number;
  giftsGiven: number;
  datesCount: number;
  conversationsCount: number;

  milestones: Milestone[];
  profile?: RelationshipProfile;

  createdAt: Date;
  updatedAt: Date;
}

export type PopulatedRelationship = WithId<Relationship>;

export type RelationshipMemoryKind =
  | 'short_term'
  | 'long_term'
  | 'milestone'
  | 'preference';

export interface RelationshipMemory {
  userId: string;
  guildId: string;
  characterId: string;
  relationshipId: ObjectId;

  kind: RelationshipMemoryKind;
  text: string;
  importance: number;
  createdAt: Date;
  lastUsedAt?: Date;
  useCount: number;
}
