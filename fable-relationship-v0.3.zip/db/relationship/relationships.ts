import type { Mongo } from '~/db/index.ts';
import type * as Schema from '~/db/relationship/schema.ts';

const clamp = (value: number, min = 0, max = 100) =>
  Math.max(min, Math.min(max, Math.round(value)));

const STATUS_ORDER: Schema.RelationshipStatus[] = [
  'met',
  'acquaintance',
  'friend',
  'close_friend',
  'romantic_interest',
  'dating',
  'engaged',
  'married',
];

function deriveStatus(r: Schema.Relationship): Schema.RelationshipStatus {
  if (r.status === 'met' && r.affection >= 15) return 'acquaintance';
  if (r.status === 'acquaintance' && r.affection >= 30) return 'friend';
  if (r.status === 'friend' && r.affection >= 55) return 'close_friend';
  if (
    r.status === 'close_friend' &&
    r.affection >= 70 &&
    r.trust >= 60
  ) return 'romantic_interest';
  return r.status;
}

export async function getRelationship(
  mongo: Mongo,
  userId: string,
  guildId: string,
  characterId: string,
): Promise<Schema.PopulatedRelationship | null> {
  return await mongo.relationships().findOne({ userId, guildId, characterId });
}

export async function ensureRelationship({
  mongo,
  userId,
  guildId,
  characterId,
}: {
  mongo: Mongo;
  userId: string;
  guildId: string;
  characterId: string;
}): Promise<Schema.PopulatedRelationship> {
  const now = new Date();
  const result = await mongo.relationships().findOneAndUpdate(
    { userId, guildId, characterId },
    {
      $setOnInsert: {
        userId,
        guildId,
        characterId,
        status: 'met',
        mood: 'curious',
        affection: 0,
        trust: 0,
        intimacy: 0,
        compatibility: 50,
        firstMet: now,
        lastInteraction: now,
        interactionCount: 0,
        giftsGiven: 0,
        datesCount: 0,
        conversationsCount: 0,
        milestones: [{ type: 'first_met', createdAt: now }],
        createdAt: now,
        updatedAt: now,
      },
    },
    { upsert: true, returnDocument: 'after' },
  );

  if (!result) throw new Error('Failed to create relationship');
  return result;
}

export async function interact({
  mongo,
  userId,
  guildId,
  characterId,
  affectionDelta = 1,
  trustDelta = 0,
  intimacyDelta = 0,
  compatibilityDelta = 0,
  mood,
  conversation = false,
  date = false,
}: {
  mongo: Mongo;
  userId: string;
  guildId: string;
  characterId: string;
  affectionDelta?: number;
  trustDelta?: number;
  intimacyDelta?: number;
  compatibilityDelta?: number;
  mood?: Schema.RelationshipMood;
  conversation?: boolean;
  date?: boolean;
}): Promise<Schema.PopulatedRelationship> {
  const current = await ensureRelationship({ mongo, userId, guildId, characterId });
  const now = new Date();
  const next: Schema.Relationship = {
    ...current,
    affection: clamp(current.affection + affectionDelta),
    trust: clamp(current.trust + trustDelta),
    intimacy: clamp(current.intimacy + intimacyDelta),
    compatibility: clamp(current.compatibility + compatibilityDelta),
    mood: mood ?? current.mood,
    interactionCount: current.interactionCount + 1,
    conversationsCount:
      current.conversationsCount + (conversation ? 1 : 0),
    datesCount: current.datesCount + (date ? 1 : 0),
    lastInteraction: now,
    updatedAt: now,
    status: current.status,
  };

  next.status = deriveStatus(next);

  const milestones = [...current.milestones];
  if (
    next.status !== current.status &&
    !milestones.some((m) => m.type === `status_${next.status}`)
  ) {
    milestones.push({ type: `status_${next.status}`, createdAt: now });
  }

  const result = await mongo.relationships().findOneAndUpdate(
    { _id: current._id },
    {
      $set: {
        affection: next.affection,
        trust: next.trust,
        intimacy: next.intimacy,
        compatibility: next.compatibility,
        mood: next.mood,
        interactionCount: next.interactionCount,
        conversationsCount: next.conversationsCount,
        datesCount: next.datesCount,
        lastInteraction: next.lastInteraction,
        status: next.status,
        milestones,
        updatedAt: next.updatedAt,
      },
    },
    { returnDocument: 'after' },
  );

  if (!result) throw new Error('Failed to update relationship');
  return result;
}

export async function giveGift({
  mongo,
  userId,
  guildId,
  characterId,
  gift,
}: {
  mongo: Mongo;
  userId: string;
  guildId: string;
  characterId: string;
  gift: string;
}): Promise<Schema.PopulatedRelationship> {
  const current = await ensureRelationship({ mongo, userId, guildId, characterId });
  const now = new Date();
  const affectionDelta = Math.min(8, 2 + Math.ceil(gift.length / 20));
  const trustDelta = 1;
  const nextAffection = clamp(current.affection + affectionDelta);
  let nextStatus = current.status;
  if (current.status === 'met' && nextAffection >= 15) nextStatus = 'acquaintance';
  else if (current.status === 'acquaintance' && nextAffection >= 30) nextStatus = 'friend';
  else if (current.status === 'friend' && nextAffection >= 55) nextStatus = 'close_friend';
  const milestones = [...current.milestones];
  if (nextStatus !== current.status && !milestones.some((m) => m.type === `status_${nextStatus}`)) {
    milestones.push({ type: `status_${nextStatus}`, createdAt: now });
  }
  const result = await mongo.relationships().findOneAndUpdate(
    { _id: current._id },
    {
      $set: {
        affection: nextAffection,
        trust: clamp(current.trust + trustDelta),
        status: nextStatus,
        milestones,
        lastInteraction: now,
        updatedAt: now,
      },
      $inc: { interactionCount: 1, giftsGiven: 1 },
    },
    { returnDocument: 'after' },
  );
  if (!result) throw new Error('Failed to give gift');
  return result;
}

export async function setStatus({
  mongo,
  userId,
  guildId,
  characterId,
  status,
  milestone,
}: {
  mongo: Mongo;
  userId: string;
  guildId: string;
  characterId: string;
  status: Schema.RelationshipStatus;
  milestone?: string;
}): Promise<Schema.PopulatedRelationship> {
  const current = await ensureRelationship({ mongo, userId, guildId, characterId });
  if (STATUS_ORDER.indexOf(status) < STATUS_ORDER.indexOf(current.status)) {
    throw new Error('Relationship status cannot move backwards');
  }

  const now = new Date();
  const milestones = [...current.milestones];
  const type = milestone ?? `status_${status}`;
  if (!milestones.some((item) => item.type === type)) {
    milestones.push({ type, createdAt: now });
  }

  const result = await mongo.relationships().findOneAndUpdate(
    { _id: current._id },
    { $set: { status, milestones, updatedAt: now } },
    { returnDocument: 'after' },
  );
  if (!result) throw new Error('Failed to update relationship status');
  return result;
}

export async function addMemory({
  mongo,
  relationship,
  text,
  kind = 'short_term',
  importance = 1,
}: {
  mongo: Mongo;
  relationship: Schema.PopulatedRelationship;
  text: string;
  kind?: Schema.RelationshipMemoryKind;
  importance?: number;
}): Promise<void> {
  const clean = text.trim().slice(0, 2000);
  if (!clean) return;
  await mongo.relationshipMemories().insertOne({
    userId: relationship.userId,
    guildId: relationship.guildId,
    characterId: relationship.characterId,
    relationshipId: relationship._id,
    kind,
    text: clean,
    importance: clamp(importance, 1, 5),
    createdAt: new Date(),
    useCount: 0,
  });
}

export async function getMemories({
  mongo,
  userId,
  guildId,
  characterId,
  limit = 10,
}: {
  mongo: Mongo;
  userId: string;
  guildId: string;
  characterId: string;
  limit?: number;
}): Promise<Schema.RelationshipMemory[]> {
  return await mongo
    .relationshipMemories()
    .find({ userId, guildId, characterId })
    .sort({ importance: -1, createdAt: -1 })
    .limit(Math.max(1, Math.min(limit, 30)))
    .toArray();
}

export async function listRelationships({
  mongo,
  userId,
  guildId,
  limit = 10,
}: {
  mongo: Mongo;
  userId: string;
  guildId: string;
  limit?: number;
}): Promise<Schema.PopulatedRelationship[]> {
  return await mongo
    .relationships()
    .find({ userId, guildId })
    .sort({ affection: -1, updatedAt: -1 })
    .limit(Math.max(1, Math.min(limit, 25)))
    .toArray();
}
