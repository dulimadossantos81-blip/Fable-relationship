import { MongoMemoryServer } from 'mongodb-memory-server';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { Mongo } from '~/db/index.ts';
import config from '~/src/config.ts';
import {
  addMemory,
  ensureRelationship,
  getMemories,
  getRelationship,
  giveGift,
  interact,
  listRelationships,
} from '~/db/relationship/relationships.ts';

let mongod: MongoMemoryServer;
let client: Mongo;

describe('relationship database', () => {
  beforeEach(async () => {
    mongod = await MongoMemoryServer.create();
    config.mongoUri = mongod.getUri();
    client = new Mongo(mongod.getUri());
  });

  afterEach(async () => {
    await client.close();
    await mongod.stop();
    delete config.mongoUri;
  });

  it('creates a relationship once and keeps it idempotent', async () => {
    const first = await ensureRelationship({
      mongo: client,
      userId: 'u1',
      guildId: 'g1',
      characterId: 'pack:1',
    });
    const second = await ensureRelationship({
      mongo: client,
      userId: 'u1',
      guildId: 'g1',
      characterId: 'pack:1',
    });

    expect(second._id).toEqual(first._id);
    expect(second.status).toBe('met');
    expect(second.affection).toBe(0);
  });

  it('progresses early relationship state and clamps values', async () => {
    await ensureRelationship({
      mongo: client,
      userId: 'u1',
      guildId: 'g1',
      characterId: 'pack:1',
    });

    const updated = await interact({
      mongo: client,
      userId: 'u1',
      guildId: 'g1',
      characterId: 'pack:1',
      affectionDelta: 1000,
      trustDelta: 1000,
      intimacyDelta: 1000,
      compatibilityDelta: 1000,
      conversation: true,
    });

    expect(updated.affection).toBe(100);
    expect(updated.trust).toBe(100);
    expect(updated.intimacy).toBe(100);
    expect(updated.compatibility).toBe(100);
    expect(updated.status).toBe('acquaintance');
    expect(updated.conversationsCount).toBe(1);
  });

  it('stores memories and gifts', async () => {
    const relationship = await ensureRelationship({
      mongo: client,
      userId: 'u1',
      guildId: 'g1',
      characterId: 'pack:1',
    });

    await addMemory({
      mongo: client,
      relationship,
      text: 'O usuário gosta de chá.',
      kind: 'preference',
      importance: 5,
    });

    const gifted = await giveGift({
      mongo: client,
      userId: 'u1',
      guildId: 'g1',
      characterId: 'pack:1',
      gift: 'chocolates',
    });

    const memories = await getMemories({
      mongo: client,
      userId: 'u1',
      guildId: 'g1',
      characterId: 'pack:1',
    });

    expect(gifted.giftsGiven).toBe(1);
    expect(gifted.interactionCount).toBe(1);
    expect(memories[0].text).toContain('chá');
  });

  it('lists relationships by affection', async () => {
    await ensureRelationship({ mongo: client, userId: 'u1', guildId: 'g1', characterId: 'pack:1' });
    await ensureRelationship({ mongo: client, userId: 'u1', guildId: 'g1', characterId: 'pack:2' });
    await interact({ mongo: client, userId: 'u1', guildId: 'g1', characterId: 'pack:2', affectionDelta: 10 });

    const list = await listRelationships({ mongo: client, userId: 'u1', guildId: 'g1' });
    expect(list.map((r) => r.characterId)).toEqual(['pack:2', 'pack:1']);
  });

  it('does not mix users or guilds', async () => {
    await ensureRelationship({ mongo: client, userId: 'u1', guildId: 'g1', characterId: 'pack:1' });
    await ensureRelationship({ mongo: client, userId: 'u2', guildId: 'g1', characterId: 'pack:1' });
    await ensureRelationship({ mongo: client, userId: 'u1', guildId: 'g2', characterId: 'pack:1' });

    expect(await getRelationship(client, 'u1', 'g1', 'pack:1')).not.toBeNull();
    expect(await getRelationship(client, 'u2', 'g1', 'pack:1')).not.toBeNull();
    expect(await getRelationship(client, 'u1', 'g2', 'pack:1')).not.toBeNull();
    expect(await listRelationships({ mongo: client, userId: 'u1', guildId: 'g1' })).toHaveLength(1);
  });
});
