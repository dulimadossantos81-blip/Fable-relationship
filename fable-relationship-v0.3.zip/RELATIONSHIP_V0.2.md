# Fable Relationship V0.2

V0.2 turns the initial relationship prototype into a small interaction loop while keeping Fable's gacha/inventory authoritative.

## Added

- Conversation through Discord modals.
- Tea, walks/dates and gifts.
- Relationship mood, compatibility and richer counters.
- Memory categories: short-term, long-term, milestone and preference.
- Character-owned validation before interaction.
- Better AI context with status, mood, relationship stats and memories.
- Graceful AI fallback when no provider key is configured.
- Relationship memory/profile UI.
- Database tests for relationship persistence and isolation.

## Environment

Optional AI configuration:

```env
RELATIONSHIP_AI_KEY=...
RELATIONSHIP_AI_BASE_URL=https://api.openai.com/v1
RELATIONSHIP_AI_MODEL=gpt-4o-mini
```

The relationship module does not make the AI authoritative. Database state remains authoritative.

## Discord

Run the command registration script after installing dependencies:

```bash
npm run discord
```

Then use:

- `/relationship profile character:<owned character>`
- `/relationship interact character:<owned character>`
- `/relationship tea character:<owned character>`
- `/relationship date character:<owned character>`
- `/relationship gift character:<owned character>`
- `/relationship memories character:<owned character>`
- `/relationship list`

## Important

V0.2 is still a relationship-simulation foundation. It does not yet implement engagement/marriage requests, advanced event scheduling, semantic memory retrieval, or adult mode. Those belong in later milestones with their own safety and state rules.
